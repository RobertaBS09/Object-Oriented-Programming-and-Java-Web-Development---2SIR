package br.com.AgroSat.Interfaces;

public interface Monitoravel {
    public void lerDadosSatelite();
    public String getUltimaLeitura();
    public double getIndiceMaturacao();
}
