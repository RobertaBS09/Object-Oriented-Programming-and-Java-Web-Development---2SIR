package br.com.AgroSat.Classes;

import br.com.AgroSat.Interfaces.Alertavel;
import br.com.AgroSat.Interfaces.Monitoravel;
import br.com.AgroSat.Modelo.*;

import java.util.ArrayList;

import static java.lang.Integer.parseInt;
import static java.lang.Double.parseDouble;
import static javax.swing.JOptionPane.*;

public class AgroSatUtil {
    private ArrayList<EntidadeLogistica> entidades = new ArrayList<>();
    private ArrayList<EventoLogistico> eventos = new ArrayList<>();

    public static double calcularD1(ArrayList<EntidadeLogistica> entidades) {
        double totalindicador = 0;
        int aux = 0;
        for (EntidadeLogistica e : entidades) {
            if (e instanceof MicroRegiaoAgricola && e.isAtivo()) {
                totalindicador += e.calcularIndicador();
                aux++;
            }
        }
        if (aux == 0) {
            return 0.0;
        }
        return totalindicador / aux;
    }

    public static double calcularD2(ArrayList<EntidadeLogistica> entidades) {
        double volumetotal = 0;
        double capacidadeTransporte = 0;
        double capacidadeArmazen = 0;

        for (EntidadeLogistica e : entidades) {
            if (e instanceof MicroRegiaoAgricola && e.isAtivo()) {
                volumetotal += ((MicroRegiaoAgricola) e).getVolumePrevisto();
            }
            if (e instanceof TransportadoraRegistrada && e.isAtivo()) {
                capacidadeTransporte += ((TransportadoraRegistrada) e).calcularCapacidadeDisponivel();
            }
            if (e instanceof ArmazenIntermediario && e.isAtivo()) {
                capacidadeArmazen += ((ArmazenIntermediario) e).calcularCapacidadeLivre();
            }
        }

        if (volumetotal == 0) {
            return 100;
        }
        double capacidadeTotal = capacidadeTransporte + capacidadeArmazen;
        double d2 = (capacidadeTotal / volumetotal) * 100;
        if (d2 > 100) {
            d2 = 100;
        }
        return d2;
    }

    public static double calcularD3(ArrayList<EventoLogistico> eventos) {
        int qtdCriticos = 0;
        for (EventoLogistico e : eventos) {
            if (e.getNivelCriticidade() == 3) {
                qtdCriticos++;
            }
        }
        int penalidade = 100 - (qtdCriticos * 20);
        if (penalidade < 0) {
            penalidade = 0;
        }
        return penalidade;
    }

    public static double calcularIPO(ArrayList<EntidadeLogistica> entidades, ArrayList<EventoLogistico> eventos) {
        double D1 = calcularD1(entidades);
        double D2 = calcularD2(entidades);
        double D3 = calcularD3(eventos);
        return (D1 * 0.4) + (D2 * 0.35) + (D3 * 0.25);
    }

    public static String classificarIpo(double ipo) {
        if (ipo >= 70) {
            return "VERDE";
        } else if (ipo >= 40) {
            return "AMARELO";
        } else {
            return "VERMELHO";
        }
    }

    public void exibirMenu() {
        int opcao = 0;
        String aux = """
                -- Bem vindo ao sistema da AgroSat! --
                [1] Cadastrar nova entidade
                [2] Listar entidades cadastradas
                [3] Executar cálculo de uma entidade
                [4] Registrar Evento
                [5] Consultar histórico de eventos
                [6] Calcular e exibir IPO
                [7] Exibir relatório geral
                [8] Sair
                """;
        do {
            try {
                opcao = parseInt(showInputDialog(aux));
                switch (opcao) {
                    case 1 -> cadastrarEntidade();
                    case 2 -> listarEntidades();
                    case 3 -> calcularCalculoEntidade();
                    case 4 -> registrarEvento();
                    case 5 -> consultarHistoricoEventos();
                    case 6 -> calcularExibirIPO();
                    case 7 -> exibirRelatorioGeral();
                    case 8 -> showMessageDialog(null, "Encerrando sistema...");
                    default -> showMessageDialog(null, "Opcao invalida! Digite um número entre 1 e 8.");
                }
            } catch (NumberFormatException e) {
                showMessageDialog(null, "Erro! Digite apenas números no menu.");
            } catch (NullPointerException e) {
                showMessageDialog(null, "Operação cancelada.");
                opcao = 8;
            }
        } while (opcao != 8);
    }

    public void cadastrarEntidade() {
        try {
            int entidade = parseInt(showInputDialog(
                    "Digite o tipo da entidade:\n[1] Microrregião Agrícola\n[2] Transportadora\n[3] Armazém"));

            if (entidade == 1) {
                String id = showInputDialog("Digite o ID: ");
                String nome = showInputDialog("Digite o nome da microrregião:");
                String regiao = showInputDialog("Digite a região:");
                String data = showInputDialog("Digite a data (DD/MM/YYYY): ");
                double areaHectares = parseDouble(showInputDialog("Digite a área em hectáres:"));
                String cultura = showInputDialog("Digite a cultura: ");

                MicroRegiaoAgricola MA = new MicroRegiaoAgricola(id, nome, regiao, data, areaHectares, cultura);
                MA.lerDadosSatelite();

                entidades.add(MA);
                showMessageDialog(null, "Microrregião cadastrada com sucesso!");

            } else if (entidade == 2) {
                String id = showInputDialog("Digite o ID: ");
                String nome = showInputDialog("Digite o nome da Transportadora:");
                String regiao = showInputDialog("Digite a região:");
                String data = showInputDialog("Digite a data (DD/MM/YYYY): ");
                int frotaTotal = parseInt(showInputDialog("Digite a frota total: "));
                int caminhoesDisponiceis = parseInt(showInputDialog("Digite o número de caminhões disponível: "));
                double capacidadeTonPorViagem = parseDouble(showInputDialog("Digite a capacidade de toneladas por viagem: "));
                int semandaDisponivel = parseInt(showInputDialog("Digite a semana disponível: "));
                double taxaOcupacaoAtual = parseDouble(showInputDialog("Digite a taxa ocupacional: "));

                TransportadoraRegistrada tr = new TransportadoraRegistrada(id, nome, regiao, data, frotaTotal,
                        caminhoesDisponiceis, capacidadeTonPorViagem, semandaDisponivel, taxaOcupacaoAtual);

                entidades.add(tr);
                showMessageDialog(null, "Transportadora cadastrada com sucesso!");

            } else if (entidade == 3) {
                String id = showInputDialog("Digite o ID: ");
                String nome = showInputDialog("Digite o nome do Armazém:");
                String regiao = showInputDialog("Digite a região:");
                String data = showInputDialog("Digite a data (DD/MM/YYYY): ");
                double capacidadeMaxTon = parseDouble(showInputDialog("Digite a capacidade máxima de toneladas: "));
                double volumeArmazenadoTon = parseDouble(showInputDialog("Digite o volume armazenado (em toneladas): "));
                double fluxoSaidaDiario = parseDouble(showInputDialog("Digite o fluxo de saída diário: "));
                String tipoArmazem = showInputDialog("Digite o tipo de armazém: ");

                ArmazenIntermediario ai = new ArmazenIntermediario(id, nome, regiao, data, capacidadeMaxTon,
                        volumeArmazenadoTon, fluxoSaidaDiario, tipoArmazem);

                entidades.add(ai);
                showMessageDialog(null, "Armazém cadastrado com sucesso!");

            } else {
                showMessageDialog(null, "Tipo inválido! Digite 1, 2 ou 3.");
            }

        } catch (NumberFormatException e) {
            showMessageDialog(null, "Erro! Digite apenas números nos campos numéricos.");
        } catch (NullPointerException e) {
            showMessageDialog(null, "Cadastro cancelado.");
        }
    }

    public void lerDadosSatelite() {
        try {
            String id = showInputDialog("Digite o ID da entidade:");
            EntidadeLogistica entidade = pesquisar(id);

            if (entidade == null) {
                showMessageDialog(null, "Entidade não encontrada!");
                return;
            }

            if (entidade instanceof Monitoravel) {
                ((Monitoravel) entidade).lerDadosSatelite();
                showMessageDialog(null, "Leitura orbital realizada com sucesso!\n"
                        + entidade.gerarRelatorioStatus());
            } else {
                showMessageDialog(null, "Esta entidade não suporta leitura orbital.");
            }

        } catch (NullPointerException e) {
            showMessageDialog(null, "Operação cancelada.");
        }
    }

    public void listarEntidades() {
        try {
            if (entidades.isEmpty()) {
                showMessageDialog(null, "Nenhuma entidade cadastrada.");
                return;
            }

            String opcao = showInputDialog(
                    """
                            Como deseja visualizar?
                            1 - Listar todas
                            2 - Buscar por ID""");

            if (opcao.equals("1")) {
                for (EntidadeLogistica e : entidades) {
                    showMessageDialog(null, e.gerarRelatorioStatus());
                }
            } else if (opcao.equals("2")) {
                String id = showInputDialog("Digite o ID da entidade:");
                EntidadeLogistica entidade = pesquisar(id);

                if (entidade != null) {
                    showMessageDialog(null, entidade.gerarRelatorioStatus());
                } else {
                    showMessageDialog(null, "Entidade não encontrada!");
                }
            } else {
                showMessageDialog(null, "Opção inválida! Digite 1 ou 2.");
            }

        } catch (NullPointerException e) {
            showMessageDialog(null, "Operação cancelada.");
        }
    }

    public EntidadeLogistica pesquisar(String id) {
        for (EntidadeLogistica e : entidades) {
            if (e.getId().equalsIgnoreCase(id)) {
                return e;
            }
        }
        return null;
    }

    public void calcularCalculoEntidade() {
        try {
            String id = showInputDialog("Digite o Id:");
            EntidadeLogistica entidade = pesquisar(id);

            if (entidade != null) {
                double resultado = entidade.calcularIndicador();
                showMessageDialog(null, "Entidade: " + entidade.getNome() + "\nIndicador: " + resultado);
            } else {
                showMessageDialog(null, "Entidade não encontrada!");
            }

        } catch (NullPointerException e) {
            showMessageDialog(null, "Operação cancelada.");
        }
    }

    public void registrarEvento() {
        try {
            String id = showInputDialog("Digite o ID do evento (ex: EVT-001):");
            String descricao = showInputDialog("Digite a descricao do evento:");
            String data = showInputDialog("Digite a data do evento (DD/MM/YYYY): ");

            String tipoEvento = showInputDialog(
                    """
                            Digite o tipo do evento:
                            1 - ALERTA_SOBRECARGA
                            2 - LEITURA_CRITICA
                            3 - FALHA_FROTA
                            4 - REGISTRO_MANUAL""");

            String tipo = switch (tipoEvento) {
                case "1" -> "ALERTA_SOBRECARGA";
                case "2" -> "LEITURA_CRITICA";
                case "3" -> "FALHA_FROTA";
                default -> "REGISTRO_MANUAL";
            };

            int nivelCriticidade = parseInt(showInputDialog(
                    """
                            Digite o nivel de criticidade:
                            1 - Baixo
                            2 - Medio
                            3 - Critico"""));

            String entidadeOrigem = showInputDialog("Digite o ID da entidade de origem do evento:");
            EntidadeLogistica entidade = pesquisar(entidadeOrigem);

            if (entidade == null) {
                showMessageDialog(null, "Entidade não encontrada! Evento não registrado.");
                return;
            }

            EventoLogistico evento = new EventoLogistico(id, descricao, data, tipo, nivelCriticidade, entidadeOrigem);
            eventos.add(evento);
            showMessageDialog(null, "Evento registrado com sucesso!\n" + evento.toString());

        } catch (NumberFormatException e) {
            showMessageDialog(null, "Erro! Digite apenas números nos campos numéricos.");
        } catch (NullPointerException e) {
            showMessageDialog(null, "Registro de evento cancelado.");
        }
    }

    public void consultarHistoricoEventos() {
        try {
            if (eventos.isEmpty()) {
                showMessageDialog(null, "Nenhuma anomalia registrada nesta sessao.");
                return;
            }

            String opcao = showInputDialog(
                    """
                            Como deseja visualizar?
                            1 - Ver todos os eventos
                            2 - Buscar por ID da entidade""");

            if (opcao.equals("1")) {
                String historico = "=== HISTORICO DE ANOMALIAS ===\n\n";
                for (EventoLogistico e : eventos) {
                    historico = historico + e.toString() + "\n\n";
                }
                showMessageDialog(null, historico);

            } else if (opcao.equals("2")) {
                String id = showInputDialog("Digite o ID da entidade:");
                EntidadeLogistica entidade = pesquisar(id);

                if (entidade != null) {
                    String historico = "=== ANOMALIAS DA ENTIDADE " + id + " ===\n\n";
                    boolean encontrou = false;

                    for (EventoLogistico e : eventos) {
                        if (e.getEntidadeOrigem().equalsIgnoreCase(id)) {
                            historico = historico + e.toString() + "\n\n";
                            encontrou = true;
                        }
                    }

                    if (!encontrou) {
                        showMessageDialog(null, "Nenhum evento para essa entidade.");
                    } else {
                        showMessageDialog(null, historico);
                    }
                } else {
                    showMessageDialog(null, "Entidade não encontrada!");
                }
            } else {
                showMessageDialog(null, "Opção inválida! Digite 1 ou 2.");
            }

        } catch (NullPointerException e) {
            showMessageDialog(null, "Operação cancelada.");
        }
    }

    public void calcularExibirIPO() {
        try {

            double capacidadeTotal = 0;
            for (EntidadeLogistica e : entidades) {
                if (e instanceof TransportadoraRegistrada && e.isAtivo()) {
                    capacidadeTotal += ((TransportadoraRegistrada) e).calcularCapacidadeDisponivel();
                }
                if (e instanceof ArmazenIntermediario && e.isAtivo()) {
                    capacidadeTotal += ((ArmazenIntermediario) e).calcularCapacidadeLivre();
                }
            }


            for (EntidadeLogistica e : entidades) {
                if (e instanceof MicroRegiaoAgricola && e.isAtivo()) {
                    ((MicroRegiaoAgricola) e).setCapacidadeLogisticaTotal(capacidadeTotal);
                }
            }


            for (EntidadeLogistica e : entidades) {
                if (e instanceof Alertavel && e.isAtivo()) {
                    Alertavel alertavel = (Alertavel) e;
                    if (alertavel.verificarSobrecarga()) {
                        alertavel.gerarAlerta("Sobrecarga detectada ao calcular IPO!");
                    }
                }
            }

            double d1 = calcularD1(entidades);
            double d2 = calcularD2(entidades);
            double d3 = calcularD3(eventos);
            double ipo = calcularIPO(entidades, eventos);
            String classificacao = classificarIpo(ipo);

            showMessageDialog(null,
                    "=== INDICE DE PRONTIDAO OPERACIONAL ===\n\n" +
                            "D1 - Maturacao  (40%): " + d1 + "\n" +
                            "D2 - Logistica  (35%): " + d2 + "\n" +
                            "D3 - Anomalias  (25%): " + d3 + "\n\n" +
                            "IPO Final: " + ipo + "\n" +
                            "Classificacao: " + classificacao);

        } catch (NullPointerException e) {
            showMessageDialog(null, "Operação cancelada.");
        }
    }

    public void exibirRelatorioGeral() {
        try {
            if (entidades.isEmpty()) {
                showMessageDialog(null, "Nenhuma entidade registrada nesta sessao.");
                return;
            }

            String opcao = showInputDialog(
                    """
                            Como deseja visualizar?
                            1 - Ver todas as entidades
                            2 - Buscar por ID""");

            if (opcao.equals("1")) {
                for (EntidadeLogistica e : entidades) {
                    showMessageDialog(null, e.gerarRelatorioStatus());
                }
            } else if (opcao.equals("2")) {
                String id = showInputDialog("Digite o ID da entidade:");
                EntidadeLogistica entidade = pesquisar(id);

                if (entidade != null) {
                    showMessageDialog(null, entidade.gerarRelatorioStatus());
                } else {
                    showMessageDialog(null, "Entidade não encontrada!");
                }
            } else {
                showMessageDialog(null, "Opção inválida! Digite 1 ou 2.");
            }

        } catch (NullPointerException e) {
            showMessageDialog(null, "Operação cancelada.");
        }
    }
}