package br.com.AgroSat.Modelo;

import br.com.AgroSat.Interfaces.Alertavel;

import static javax.swing.JOptionPane.showMessageDialog;


public class TransportadoraRegistrada extends EntidadeLogistica implements Alertavel {
    private int frotaTotal;
    private int caminhoesDisponiveis;
    private double capacidadeTonPorViagem;
    private int semanaDisponivel;
    private double taxaOcupacaoAtual;

    public TransportadoraRegistrada(String id, String nome, String regiao, String dataRegistro, int frotaTotal, int caminhoesDisponiveis, double capacidadeTonPorViagem, int semanaDisponivel, double taxaOcupacaoAtual) {
        super(id, nome, regiao, dataRegistro);
        this.frotaTotal = frotaTotal;
        this.caminhoesDisponiveis = caminhoesDisponiveis;
        this.capacidadeTonPorViagem = capacidadeTonPorViagem;
        this.semanaDisponivel = semanaDisponivel;
        this.taxaOcupacaoAtual = taxaOcupacaoAtual;
    }

    @Override
    public boolean verificarSobrecarga() {
        return taxaOcupacaoAtual > 0.90;
    }

    @Override
    public int getNivelRisco() {
        if (taxaOcupacaoAtual <= 0.75) {
            return 1;
        } else if (taxaOcupacaoAtual <= 0.90) {
            return 2;
        } else {
            return 3;
        }

    }

    @Override
    public void gerarAlerta(String descricao) {
        String aux = "";
        aux += "---ALERTA---" +
                " \nTransportadora: " + nome +
                "\nTaxa de ocupação: " + (taxaOcupacaoAtual * 100) + "%" +
                "\nNível de Risco: " + getNivelRisco() + "/3" +
                "\nDescrição: " + descricao;

        showMessageDialog(null, aux);

    }

    @Override
    public double calcularIndicador() {
        return (((double) caminhoesDisponiveis / frotaTotal)) * (1 - taxaOcupacaoAtual) * 100;
    }

    public double calcularCapacidadeDisponivel() {
        return caminhoesDisponiveis*capacidadeTonPorViagem*(1-taxaOcupacaoAtual);
    }

    @Override
    public String gerarRelatorioStatus() {
        String aux = "";
        aux += "=== TRANSPORTADORA REGISTRADA ===" +
                "\nId: " + getId() +
                "\nNome: " + getNome() +
                "\nRegião: " + regiao +
                "\nFrota Total: " + frotaTotal + " caminhões" +
                "\nCaminhões disponíveis: " + caminhoesDisponiveis +
                "\nCapacidade/viagem: " + capacidadeTonPorViagem + " t" +
                "\nCapacidade disponível: " + calcularCapacidadeDisponivel() + " t" +
                "\nTaxa ocupação: " + (taxaOcupacaoAtual*100) + "%" +
                "\nSemana disponível: " + semanaDisponivel +
                "\nStatus: " + ativo;

        return aux;
    }
}
