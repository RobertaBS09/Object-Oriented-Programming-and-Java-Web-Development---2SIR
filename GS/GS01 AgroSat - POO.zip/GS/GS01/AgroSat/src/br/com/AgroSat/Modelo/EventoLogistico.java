package br.com.AgroSat.Modelo;

public class EventoLogistico {
    private String id;
    private String descricao;
    private String data;
    private String tipoEvento;
    private int nivelCriticidade;
    private String entidadeOrigem;

    public EventoLogistico(String id, String descricao, String dataHora, String tipoEvento, int nivelCriticidade, String entidadeOrigem) {
        this.id = id;
        this.descricao = descricao;
        this.data = dataHora;
        this.tipoEvento = tipoEvento;
        this.nivelCriticidade = nivelCriticidade;
        this.entidadeOrigem = entidadeOrigem;
    }

    public String getDescricao() {
        return descricao;
    }

    public String getData() {
        return data;
    }

    public String getTipoEvento() {
        return tipoEvento;
    }

    public int getNivelCriticidade() {
        return nivelCriticidade;
    }

    public String getEntidadeOrigem() {
        return entidadeOrigem;
    }

    @Override
    public String toString() {
        return "Id: "+ id+
                "\nTipo Evento: "+tipoEvento+
                "\nCriticidade: "+nivelCriticidade+
                "\nOrigem: "+entidadeOrigem+
                "\nDescrição: "+descricao;
    }
}
