package br.com.AgroSat.Modelo;

import br.com.AgroSat.Interfaces.Monitoravel;

import static java.lang.Double.parseDouble;
import static javax.swing.JOptionPane.showInputDialog;


public class ArmazenIntermediario extends EntidadeLogistica implements Monitoravel {
    private double capacidadeMaxTon;
    private double volumeArmazenadoTon;
    private double fluxoSaidaDiario;
    private String tipoArmazem;
    private double umidadeAtual;
    private double temperaturaAtual;
    private int prazoLiberacaoDias;

    public ArmazenIntermediario(String id, String nome, String regiao, String dataRegistro, double capacidadeMaxTon, double volumeArmazenadoTon, double fluxoSaidaDiario, String tipoArmazem) {
        super(id, nome, regiao, dataRegistro);
        this.capacidadeMaxTon = capacidadeMaxTon;
        this.volumeArmazenadoTon = volumeArmazenadoTon;
        this.fluxoSaidaDiario = fluxoSaidaDiario;
        this.tipoArmazem = tipoArmazem;
        this.umidadeAtual = 0;
        this.temperaturaAtual = 0;
        this.prazoLiberacaoDias = 0;
    }

    @Override
    public void lerDadosSatelite() {
        umidadeAtual = parseDouble(showInputDialog("Informe a umidade atual captada pelo satélite (%): "));
        temperaturaAtual = parseDouble(showInputDialog("Informe a temperatura atual captada pelo satélite (°C): "));
        calcularPrazoLiberacao();
    }

    @Override
    public String getUltimaLeitura() {
        if (umidadeAtual == 0 && temperaturaAtual == 0) {
            return "Nenhuma leitura orbital realizada";
        } else return "Umidade: " + umidadeAtual + "% | Temperatura: " + temperaturaAtual + "°C";
    }

    @Override
    public double getIndiceMaturacao() {
        if (temperaturaAtual > 30 || umidadeAtual > 80) {
            return 1.0;
        } else if (temperaturaAtual > 25 || umidadeAtual > 70) {
            return 0.5;
        } else {
            return 0.0;
        }

    }

    @Override
    public double calcularIndicador() {
        return (volumeArmazenadoTon / capacidadeMaxTon) * 100;
    }

    public double calcularCapacidadeLivre() {
        return capacidadeMaxTon - volumeArmazenadoTon;
    }

    public int calcularPrazoLiberacao() {
        prazoLiberacaoDias = (int) Math.ceil(volumeArmazenadoTon / fluxoSaidaDiario); // esse math.ceil é para arredondar para o dia de cima, se nao colocar ele vai arredondar para baixo
        return prazoLiberacaoDias;
    }

    @Override
    public String gerarRelatorioStatus() {
        String aux="";
        aux+="=== ARMAZÉM INTERMEDIÁRIO — Monitoramento Orbital ==="+
                "\nId: "+getId()+
                "\nNome: "+getNome()+
                "\nRegião: "+regiao+
                "\nTipo: "+tipoArmazem+
                "\nCapacidade máxima: "+ capacidadeMaxTon + " t"+
                "\nVolume armazenado: "+volumeArmazenadoTon+ "t"+
                "\nCapacidade livre: "+ calcularCapacidadeLivre()+ "t"+
                "\nPrazo liberação: "+ calcularPrazoLiberacao()+ " dias"+
                "\nÚltima leitura: "+ getUltimaLeitura()+
                "\nÍndice de conservação: "+getIndiceMaturacao()+
                "\nStatus: "+ativo;
        return aux;
    }



    public String getTipoArmazem() {
        return tipoArmazem;
    }
}
