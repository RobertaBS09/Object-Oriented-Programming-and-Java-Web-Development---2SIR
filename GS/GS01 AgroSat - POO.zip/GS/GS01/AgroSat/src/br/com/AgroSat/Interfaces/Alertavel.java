package br.com.AgroSat.Interfaces;

public interface Alertavel {
    public boolean verificarSobrecarga();
    public void gerarAlerta (String descricao);
    public int getNivelRisco();
}
