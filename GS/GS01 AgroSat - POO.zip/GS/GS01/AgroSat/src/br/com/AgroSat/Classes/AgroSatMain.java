package br.com.AgroSat.Classes;

public class AgroSatMain {
    public static void main(String[] args) {
        new AgroSatUtil().exibirMenu();
    }
}
