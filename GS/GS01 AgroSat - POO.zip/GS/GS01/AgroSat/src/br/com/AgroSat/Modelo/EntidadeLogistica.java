package br.com.AgroSat.Modelo;

public abstract class EntidadeLogistica {
    protected String id;
    protected String nome;
    protected String regiao;
    protected String dataRegistro;
    protected boolean ativo;

    public EntidadeLogistica(String id, String nome, String regiao, String dataRegistro) {
        this.id = id;
        this.nome = nome;
        this.regiao = regiao;
        this.dataRegistro = dataRegistro;
        this.ativo = true;
    }

    public abstract double calcularIndicador();
    public abstract String gerarRelatorioStatus();



    public String getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }
}
