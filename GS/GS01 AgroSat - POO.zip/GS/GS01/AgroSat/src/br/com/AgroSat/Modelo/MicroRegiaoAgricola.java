package br.com.AgroSat.Modelo;

import br.com.AgroSat.Interfaces.Alertavel;
import br.com.AgroSat.Interfaces.Monitoravel;

import static java.lang.Double.parseDouble;
import static javax.swing.JOptionPane.showInputDialog;
import static javax.swing.JOptionPane.showMessageDialog;

public class MicroRegiaoAgricola extends EntidadeLogistica implements Monitoravel, Alertavel {
    private double areaHectares;
    private String culturaPrincipal;
    private double ndviAtual;
    private double ndwiAtual;
    private int diasParaColheita;
    private double volumePrevisto;
    private double capacidadeLogisticaTotal;

    public MicroRegiaoAgricola(String id, String nome, String regiao, String dataRegistro, double areaHectares, String culturaPrincipal) {
        super(id, nome, regiao, dataRegistro);
        this.areaHectares = areaHectares;
        this.culturaPrincipal = culturaPrincipal;
        this.ndviAtual = 0;
        this.ndwiAtual = 0;
        this.diasParaColheita = 0;
        this.volumePrevisto = 0;
    }

    @Override
    public void lerDadosSatelite() {
        do {

            this.ndviAtual = parseDouble(
                    showInputDialog(
                            null, "Digite o NDVI atual captado pelo Sentinel-2 (0.0 a 1.0): "
                    )
            );

            if (ndviAtual < 0 || ndviAtual > 1) {

                showMessageDialog(
                        null, "Por favor, digite um valor entre 0.0 e 1.0"
                );
            }

        } while (ndviAtual < 0 || ndviAtual > 1);

        do {

            this.ndwiAtual = parseDouble(
                    showInputDialog(
                            null, "Digite o NDWI atual captado pelo Sentinel-2 (0.0 a 1.0):"
                    )
            );

            if (ndwiAtual < 0 || ndwiAtual > 1) {

                showMessageDialog(
                        null, "Por favor, digite um valor entre 0.0 e 1.0"
                );
            }

        } while (ndwiAtual < 0 || ndwiAtual > 1);


        calcularVolumePrevisto();
        calcularDiasParaColheita();
    }


    @Override
    public String getUltimaLeitura() {
        if (this.ndviAtual == 0 && ndwiAtual == 0) {
            return "Nenhuma Leitura Orbital Realizada";
        } else {
            return "NDVI: " + ndviAtual + " | NDWI: " + ndwiAtual;
        }

    }

    @Override
    public double getIndiceMaturacao() {
        return ndviAtual;
    }

    @Override
    public boolean verificarSobrecarga() {
        return volumePrevisto > capacidadeLogisticaTotal;
    }

    @Override
    public int getNivelRisco() {
        double excesso;
        excesso = ((volumePrevisto - capacidadeLogisticaTotal) / capacidadeLogisticaTotal) * 100;

        if (excesso <= 10) {
            return 1;
        } else if (excesso <= 30) {
            return 2;
        } else {
            return 3;
        }
    }

    @Override
    public void gerarAlerta(String descricao) {
        String aux = "Região: " + nome +
                "\nNível de Risco: " + getNivelRisco() + "/3" +
                "\nDescrição: " + descricao;
        showMessageDialog(null, aux);
    }

    @Override
    public double calcularIndicador() {
        return ndviAtual * 100;
    }

    public void calcularVolumePrevisto() {
        double rendimento = switch (culturaPrincipal.toLowerCase()) {
            case "soja" -> 3.2;
            case "milho" -> 5.0;
            case "cana" -> 80.0;
            default -> 2.5;
        };

        volumePrevisto = areaHectares * rendimento * ndviAtual;

    }

    public void calcularDiasParaColheita() {
        if (ndviAtual >= 0.80) {
            diasParaColheita = 0;
        } else if (ndviAtual >= 0.60) {
            diasParaColheita = 15;
        } else if (ndviAtual >= 0.40) {
            diasParaColheita = 30;
        } else {
            diasParaColheita = 60;
        }
    }

    @Override
    public String gerarRelatorioStatus() {
        String aux = "";
        aux += "=== MICRORREGIÃO AGRÍCOLA - Monitoramento Orbital ===  " +
                "\nId: " + getId() +
                "\nNome: " + getNome() +
                "\nRegião: " + regiao +
                "\nCultura: " + culturaPrincipal +
                "\nÁrea: " + areaHectares + " ha" +
                "\nNDVI atual (Sentinel - 2): " + ndviAtual +
                "\nNDWI atual: " + ndwiAtual + " (Sentinel -2)" +
                "\nÚltima leitura: " + getUltimaLeitura() +
                "\nVolume Previsto: " + volumePrevisto + " t" +
                "\nDias p/colheita: " + diasParaColheita + " dias" +
                "\nÍndice de Maturação: " + getIndiceMaturacao()+
                "\nScore indicador: " + calcularIndicador() +
                "\nStatus: " + ativo;
        return aux;
    }

    public void setCapacidadeLogisticaTotal(double capacidadeLogisticaTotal) {
        this.capacidadeLogisticaTotal = capacidadeLogisticaTotal;
    }

    public double getVolumePrevisto() {
        return volumePrevisto;
    }
}
