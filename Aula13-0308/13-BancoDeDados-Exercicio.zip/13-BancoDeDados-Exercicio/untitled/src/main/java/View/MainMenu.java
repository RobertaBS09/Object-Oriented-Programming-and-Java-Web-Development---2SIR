package View;

import static javax.swing.JOptionPane.*;

public class MainMenu {

    public void menu(){
        String [] item = {"Vendedor","Venda","Finalizar"};
        String opcao;

        do {
            opcao = (String) showInputDialog(null,
                    "Selecione uma opção",
                    "Menu Principal",INFORMATION_MESSAGE,
                    null, item,item[0]); //criando a formatacao da janelinha o (String) veio por conta do objeto item

            switch (opcao.toLowerCase()){
                case "vendedor" ->  new MenuVendedor().menu();
                case "venda" ->  new MenuVenda().menu();
            }

        }while (!opcao.toLowerCase().equals("finalizar"));
    }
}
