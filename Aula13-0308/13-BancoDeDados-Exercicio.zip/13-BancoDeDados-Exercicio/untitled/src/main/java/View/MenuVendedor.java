package View;

import DAO.VendedorDAO;
import Model.Vendedor;

import static javax.swing.JOptionPane.INFORMATION_MESSAGE;
import static javax.swing.JOptionPane.showInputDialog;

public class MenuVendedor {
    public void menu(){
        String [] item = {"Cadastrar","Listar","Pesquisar","Atualizar","Excluir" ,"Finalizar"};
        String opcao;
        do {
            opcao = (String) showInputDialog(null,
                    "Selecione uma opção",
                    "Menu Vendedor",
                    INFORMATION_MESSAGE,
                    null,
                    item,item[0]);

            switch (opcao.toLowerCase()){
                case "cadastrar" -> inserir();
                case "listar" -> listar();
                case "pesquisar" -> pesquisar();

            }
        }while (!opcao.toLowerCase().equals("finalizar"));
    }

    private void pesquisar() {
    }

    private void listar() {
    }

    private void inserir() {
        Vendedor vendedor = new Vendedor();
        String nome = showInputDialog("Digite o nome do vendedor: ");
        vendedor.setNome(nome); //usando set pq decidimos nao usar o vendedor (pq tinha que ficar criando varios contrutures)
        new VendedorDAO().inserir(vendedor);

    }


}
