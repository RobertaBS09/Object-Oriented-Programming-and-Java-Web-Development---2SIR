package View;

import DAO.VendedorDAO;
import Model.Vendedor;

import java.util.List;

import static javax.swing.JOptionPane.*;

public class MenuVenda {
    public void menu(){
        String [] item = {"Cadastrar","Listar","Pesquisar","Atualizar","Excluir" ,"Finalizar"};
        String opcao;
        do {
            opcao = (String) showInputDialog(null,
                    "Selecione uma opção",
                    "Menu Venda",
                    INFORMATION_MESSAGE,
                    null,
                    item,item[0]);

            switch (opcao.toLowerCase()){
                case "cadastrar" -> inserir();
                case "listar" -> listar();
                case "pesquisar" -> pesquisar();

            }
        }while (!opcao.toLowerCase().equals("finalizar"));
    }

    private void pesquisar() {
    }

    private void listar() {
    }

    private void inserir() {
        List < Vendedor> lista = new VendedorDAO().listar();
        Double total;
        String data;
        Vendedor vendedor;

        vendedor =(Vendedor) showInputDialog(null, //transformamos para vendedor por conta do mesmo babado que o string la
                "Selecione um vendedor",
                "Vendedores",
                INFORMATION_MESSAGE,
                null,
                lista.toArray(),
                lista.get(0));

    }
}
