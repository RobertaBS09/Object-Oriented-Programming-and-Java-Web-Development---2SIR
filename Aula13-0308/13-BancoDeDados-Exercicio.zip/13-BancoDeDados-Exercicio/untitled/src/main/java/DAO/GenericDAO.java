package DAO;

import java.util.List;

//interface generica para implementar em todas as tabelas e nao ter confluto de nome de metodo
public interface GenericDAO <T,ID>{
    public void inserir(T entidade);
    public List <T> listar();
}
